class Individuo:

    def __init__(self, genes, peso, fitness, numItems):
        self.numItems = numItems
        self.genes = genes
        self.peso = peso
        self.fitness = fitness