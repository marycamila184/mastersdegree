class Objeto:

    def __init__(self, peso, valor):
        self.peso = peso
        self.valor = valor