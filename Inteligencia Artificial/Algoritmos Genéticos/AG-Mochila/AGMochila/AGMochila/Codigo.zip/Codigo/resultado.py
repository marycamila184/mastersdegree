class Resultado:

    def __init__(self, geracao, individuo, fitness, execucao):
        self.geracao = geracao
        self.individuo = individuo
        self.fitness = fitness
        self.execucao = execucao